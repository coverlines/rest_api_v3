// ------------------------------- S E R V E R
const express = require('express')
const logger = require('morgan')
const cookieParser = require('cookie-parser')
const bodyParser = require('body-parser')
const app = express()

// ------------------------------- M O N G O O S E   C O N N E C T   D B
const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost:27017/promo-check') 
// last arg is the name of db --> 'promo-check'

// ------------------------------- R O U T E R S
const userRoutes = require('./routes/userRoutes')
const apiRoutes = require('./routes/apiRoutes')
const appRoutes = require('./routes/appRoutes')



const fileUpload = require('express-fileupload')


// ------------------------------- M I D D L E W A R E
// set used modules
app.use(logger('dev'))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: false}))
app.use(cookieParser())

app.use(fileUpload())

// set headers for HTTP... for CORS
app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*')
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization')
    res.setHeader('Access-Control-Allow-Methods', 'POST, GET, PATCH, DELETE, OPTIONS')
    next()
})

// ------------------------------- A P I   R O U T I N G
app.use('/api', apiRoutes)
app.use('/user', userRoutes)
app.use('/', appRoutes)

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    return res.send('<h1>404 PAGE IS NOT FOUND</h1>')
})

module.exports = app

































// var express = require('express')
// // var path = require('path')
// // var favicon = require('serve-favicon')
// var logger = require('morgan')
// var cookieParser = require('cookie-parser')
// var bodyParser = require('body-parser')

// var appRoutes = require('./routes/app')

// var app = express()

// // view engine setup
// // app.set('views', path.join(__dirname, 'views'))
// // app.set('view engine', 'hbs')

// // uncomment after placing your favicon in /public
// //app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')))

// app.use(logger('dev'))
// app.use(bodyParser.json())
// app.use(bodyParser.urlencoded({extended: false}))
// app.use(cookieParser())
// // app.use(express.static(path.join(__dirname, 'public')))

// app.use(function (req, res, next) {
//     res.setHeader('Access-Control-Allow-Origin', '*')
//     res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept')
//     res.setHeader('Access-Control-Allow-Methods', 'POST, GET, PATCH, DELETE, OPTIONS')
//     next()
// })

// app.use('/', appRoutes)

// // catch 404 and forward to error handler
// app.use(function (req, res, next) {
//     return res.render('index')
// })

// // module.exports = app












// // ------------------------------- S E R V E R
// const express = require('express')
// const app = express()
// const router = express.Router()
// const port = 5000

// const bodyParser = require('body-parser')
// // ------------------------------- J W T
// const jwt = require('jsonwebtoken')
// const bcrypt = require('bcryptjs')
// // ------------------------------- E X T R A   M O D U L E S
// const csvToArray = require('./modules/csvToArray.js')
// const csvFilePath = './data/csv/PharmacyList_notutf8.csv'
// // ------------------------------- A U T H
// const SECRET_KEY = "dataprotectfy"
// // const secureRoutes = express.Router()
// // ------------------------------- G E T   A R R A Y
// let csvArray = csvToArray(csvFilePath)
// // console.log('\nP A R S E D :\n'+ csvArray +'\n\nY U P P   P A R S E D!!!\n')
// // ------------------------------- M I D D L E W A R E
// // parse application/x-www-form-urlencoded
// app.use(bodyParser.urlencoded({ extended: false }))
// // parse application/json
// app.use(bodyParser.json())
// app.use('/secure-api', secureRoutes)


// router.post('/', (req,res,next) => {
//   let user = {
//     firstName: req.body.firstName,
//     lastName: req.body.lastName,
//     password: bcrypt.hashSync(req.body.password, 10),
//     email: req.body.email
//   }

//   user.save((err, result) => { // USE MONGOOSE MODELS
//     if(err) {
//       return res.status(500).json({title: 'E R R O R', error: err})
//     }
//     res.status(201).json({ message: 'User created', obj: result})
//   })


// })




// // this.app.use(function(req, res, next) {
// //   res.header("Access-Control-Allow-Origin", "*")
// //   res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT")
// //   res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization, access-control-allow-origin, profilerefid(whatever header you need)")
// //   next()
// //   })







// // ------------------------------- A P I   R O U T I N G
// // app.get('/apis/authenticate', function (req, res) {
  
// //   let user = {
// //     password: 'test',
// //     email: 'test@test.com'
// //   }
  
// //   let token = jwt.sign(user, SECRET_KEY, {
// //     expiresIn: 4000
// //   })

// //   // res.json({
// //   //   success: true,
// //   //   token: token
// //   // })

// //   console.log(token)
// //   res.end()

// // })


// // ------------------------------- A P I   R O U T I N G
// app.get('/apis/promocheck/pharmacy', function (req, res) {
//   res.status(200).send(csvArray)
// })
// // // ------------------------------- A P I   R O U T I N G   S E C U R E
// // secureRoutes.use( function (req, res, next) {
// //   let token = req.body.token || req.headers['token']
// //   if (token) {
// //     console.log("GOT A TOKEN")
// //     jwt.verify(token, SECRET_KEY, (err, decode)=>{
// //       if (!err) {
// //         next()
// //       } else {
// //         console.log("INVALID TOKEN")
// //         res.status(403)
// //       }
// //     })

// //   } else {
// //     console.log("DIDN'T GET A TOKEN")
// //   }
// // })

// // secureRoutes.post('/apis/promocheck/pharmacy', function (req, res) {
// //   res.status(200).send(csvArray)
// // })

// // ------------------------------- S E R V E R   L I S T E N
// app.listen(port, function () {
//   console.log('>>> API listening on port '+ port +' !!!')
// })
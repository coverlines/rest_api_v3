const mongoose = require('mongoose')
const Schema = mongoose.Schema

const schema = new Schema({
    content: {type: String, required: true},
    user: {type: Schema.Types.ObjectId, ref: 'User'}
})
// collection name is 'messages' and is generated automatically by mongoose
module.exports = mongoose.model('Message', schema)
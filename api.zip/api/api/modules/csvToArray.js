// This module needs the path to CSV file as parameter...
// ------------------------------- U S E D   M O D U L E S
const fs = require('fs')
const chardet = require('chardet')
const encoding = require('encoding')
const Papa = require("papaparse")
// ------------------------------- E X P O R T E D   O B J E C T
module.exports = (csvFilePath) => {
	let usedEncoding,
		fileContent
	try {
		// console.log('T R Y');
		usedEncoding = chardet.detectFileSync(csvFilePath) // get Encoding of file
		// console.log(usedEncoding);
		fileContent = fs.readFileSync(csvFilePath) // get the Buffer from file
		// console.log(fileContent);
		fileContent = encoding.convert(fileContent, 'UTF-8', usedEncoding) // get encoding Object of buffer in utf-8
		fileContent = fileContent.toString('utf-8') // get String from object
		// console.log(typeof fileContent) // to check the types of content
		fileContent = Papa.parse(fileContent, { header: false }) // parse CSV-String to Object with arrays inside (data, errors, meta)
		// fileContent = Papa.parse(fileContent, { header: true }) // when the arrays will be parsed in JSON is better to set header to true

		return (fileContent.data) // send array... [0] are lables...
	
	} catch (err) {
		console.error(err);
	}
}
// ------------------------------- M O D U L E S
// express
const express = require('express')
const router = express.Router()

// authorization
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')


const save = require('save-file')

// handle Upload mages

// var fs = require('fs')
// const fileUpload = require('express-fileupload')

// ------------------------------- D B - M O D E L (mongoose)
// get API DATA (Pharmacy List) --- ARRAY
// // ------------------------------- E X T R A   M O D U L E S
const csvToArray = require('../modules/csvToArray.js')
const csvFilePath = './api/data/csv/PharmacyList_notutf8.csv'
// // ------------------------------- G E T   A R R A Y
let csvArray = csvToArray(csvFilePath)
console.log('\nP A R S E D :\n'+ csvArray +'\n\nY U P P   P A R S E D!!!\n')


// G E T
// route: api/pharmacy
router.get('/pharmacy', function (req, res, next) {
    res.status(200).send(csvArray)
    // res.send('<h1>Pharmacy Data</h1>')
    // SEND DATA (Pharmacy List) --- ARRAY
})

// router.post('/pharmacy', function (req, res, next) {

// 	console.log(req)

// 	if (!req.files) return res.status(400).send('No files were uploaded.')

// 	console.log(req.files.image)

// 	res.send('<h1>Pharmacy Data</h1>')

//   Use the mv() method to place the file somewhere on your server



router.post('/pharmacy', function (req, res, next) {

	// console.log(req)
  if (!req.files)
    return res.status(400).send('No files were uploaded.')

  // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
  // let sampleFile = req.files.image
  // console.log(sampleFile)
  console.log(req.body.olafoo)
  console.log(req.files.image.name)
  console.log(req.files.image1.name)
  // console.log(req.body.olafoo)
// 	console.log('DATA FROM CLIENT')
// 	// console.log(req.body.data.exif.Thumbnail) // blob...
// 	// console.log(req.body.data.preview)
// 	res.send('INDEX: ' + req.body.i)

//     // res.status(200).send(csvArray)
	res.send('<h1>Pharmacy Data</h1>')
//     // SEND DATA (Pharmacy List) --- ARRAY
})

// ------------------------------- A P I   R O U T I N G
// ------------------------------- A F T E R   A U T H   R O U T I N G
// middleware
// route: api/
// router.use('/', function (req, res, next) {
//     console.log(req)
//     jwt.verify(req.query.token, 'secret', function (err, decoded) {

//         if (err) {
//             return res.status(401).json({
//                 title: 'Not Authenticated',
//                 error: err
//             })
//         }
//         next()
//     })
// })

// // G E T
// // route: api/pharmacy
// router.get('/pharmacy', function (req, res, next) {
// 	res.send('<h1>Pharmacy Data</h1>')
//     // SEND DATA (Pharmacy List) --- ARRAY
// })

// P O S T
// router.post('/apis/pharmacy', function (req, res, next) {
//     res.send('<h1>Pharmacy Data</h1>')
//     // SAVE NEW DATA IN PHARMACY DB AND PUT IMAGES IN RIGHT FOLDERS...
// })

module.exports = router
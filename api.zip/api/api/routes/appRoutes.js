// ------------------------------- M O D U L E S
// express
const express = require('express')
const router = express.Router()

// ------------------------------- A P I   R O U T I N G
// G E T
router.get('/', function (req, res, next) {
    res.send('<h1>index</h1>')
})

module.exports = router
// ------------------------------- M O D U L E S
// express
const express = require('express')
const router = express.Router()

// authorization
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')

// ------------------------------- D B - M O D E L (mongoose)
let User = require('../models/user')

// ------------------------------- A P I   R O U T I N G
// P O S T - signin // see comments --- will comming // basic athorization
// http://localhost:5000/user/signin
router.post('/signin', function (req, res, next) {
    let user = new User({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        password: bcrypt.hashSync(req.body.password, 10),
        email: req.body.email
    })
// ------------------------------- T E S T   O B J E C T
// ------------------------------- how to put a new User to DB

// in developing version use postman --- https://www.getpostman.com/
// select -- POST -Body-raw//-put JSON Object -//  select JSON-Application
// push SEND
// to create a new user... Here is the basic object to send via http post

// {
// 	"firstName": "Test",
// 	"lastName": "Testoff",
// 	"password": "test",
// 	"email": "test@test.test"
// }

// email should be unique !!!

// ------------------------------- T E S T   O B J E C T   E N D
    user.save(function(err, result) {
        if (err) {
            return res.status(500).json({
                title: 'An error occurred',
                error: err
            })
        }
        res.status(201).json({
            message: 'User created',
            obj: result
        })
    })
})

// P O S T - login
// http://localhost:5000/user/login
router.post('/login', function(req, res, next) {

    console.log('>>> P O S T\n', req.headers.authorization, '\n')

    User.findOne({email: req.body.email}, function(err, user) {
        if (err) {
            return res.status(500).json({
                title: 'An error occurred',
                error: err
            })
        }
        // ------------------------------------
        if (!user) { // failed email
            return res.status(401).json({
                title: 'Login failed',
                error: {message: 'Invalid login credentials'}
            })
        }
        if (!bcrypt.compareSync(req.body.password, user.password)) { // failed password
            return res.status(401).json({
                title: 'Login failed',
                error: {message: 'Invalid login credentials'}
            })
        }
        // ------------------------------------
        
        let token = jwt.sign({user: user}, 'secret', {expiresIn: 180}) // 604800: one week in seconds
        res.status(200).json({
            message: 'Successfully logged in',
            token: token,
            userId: user._id,
        })
    })
})

// router.get('/', function (req, res, next) {
//     res.status(200).send('<h1>USER</h1>')
// })

module.exports = router

// // ------------------------------- A P I   R O U T I N G
// // ------------------------------- A F T E R   A U T H   R O U T I N G
// // middleware

// router.use('/', function (req, res, next) {

//     jwt.verify(req.query.token, 'secret', function (err, decoded) {

//         if (err) {
//             return res.status(401).json({
//                 title: 'Not Authenticated',
//                 error: err
//             })
//         }
//         next()
//     })
// })

// P O S T - signin
// router.post('/basicauth', function (req, res, next) {

//     let user = new User({
//         firstName: req.body.firstName,
//         lastName: req.body.lastName,
//         password: bcrypt.hashSync(req.body.password, 10),
//         email: req.body.email
//     })
//     user.save(function(err, result) {
//         if (err) {
//             return res.status(500).json({
//                 title: 'An error occurred',
//                 error: err
//             })
//         }
//         res.status(201).json({
//             message: 'User created',
//             obj: result
//         })
//     })
// })

// module.exports = router